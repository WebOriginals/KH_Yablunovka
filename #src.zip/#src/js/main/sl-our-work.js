var swiper = new Swiper('.our-work-container', {
    navigation: {
        nextEl: '.our-work-button-next',
        prevEl: '.our-work-button-prev',
    },
    allowTouchMove:false,
});